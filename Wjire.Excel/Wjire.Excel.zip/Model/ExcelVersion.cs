﻿namespace Wjire.Excel.Model
{
    public enum ExcelVersion : byte
    {
        Excel2003 = 0,
        Excel2007 = 1
    }
}
